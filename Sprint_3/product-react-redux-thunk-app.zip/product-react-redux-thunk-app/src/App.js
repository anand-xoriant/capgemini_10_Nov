import './App.css';
import ProductApp from './components/product_app';

function App(props) {
  return (
    <div className="App">
      <ProductApp store={props.store} />
    </div>
  );
}

export default App;
