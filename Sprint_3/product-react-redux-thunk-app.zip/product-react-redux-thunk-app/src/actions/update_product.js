import axios from 'axios';

const UpdateProductAction = (productObj) => {
    return async function(dispatch) {
        const res = await axios.put(
            "http://localhost:8080/myapp/product/" + productObj.id,
                { 
                    name: productObj.name, 
                    quantity: productObj.quantity,
                    price: productObj.price
                }, 
                { 
                    "Content-type": "application/json; charset=UTF-8"
                }
            );
          console.log('Update Product serverResponse: ', res.data);
          dispatch({type: "UPDATE_PRODUCT", payload: res.data});

    }
}

export default UpdateProductAction;
