import axios from 'axios';

let GetProductsAction = () => {
    return async function (dispatch) {
        const res = await axios.get(
            "http://localhost:8080/myapp/product"
          );
          dispatch({type: "GET_PRODUCTS", payload: res.data});
    }
}

export default GetProductsAction;
