import axios from 'axios';

const DeleteProductAction = (productId) => {
    return async function(dispatch) {
        const res = await axios.delete(
            "http://localhost:8080/myapp/product/" + productId, { 
                headers: { 
                    "Content-type": "application/json; charset=UTF-8"
                }
            });
          console.log('Delete Product serverResponse: ', res.data);
          dispatch({type: "DELETE_PRODUCT_BY_ID", payload: res.data});

    }
}

export default DeleteProductAction;
