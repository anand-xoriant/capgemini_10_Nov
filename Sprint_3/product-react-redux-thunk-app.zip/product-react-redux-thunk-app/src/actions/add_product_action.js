import axios from 'axios';

const AddProductAction = (productObj) => {
    return async function(dispatch) {
        const res = await axios.post(
            "http://localhost:8080/myapp/product",
                { 
                    name: productObj.name, 
                    quantity: productObj.quantity,
                    price: productObj.price
                }, 
                { 
                    "Content-type": "application/json; charset=UTF-8"
                }
            );
          console.log('Add Product serverResponse: ', res.data);
          dispatch({type: "ADD_PRODUCT", payload: res.data});

    }
}

export default AddProductAction;
