import './App.css';
import { useDispatch, useSelector } from 'react-redux';
import increment from './actions/increment';
import decrement from './actions/decrement';

import { Link } from 'react-router-dom';

let dispatcher;

function App() {
  dispatcher = useDispatch();
  let count = useSelector((state)=>state);
  return (
    <div className="App">
        <input type='button' value='+' onClick={incrementClick}></input>
        <input type='button' value='-' onClick={decrementClick}></input>
        <br></br>
        <h1>Count = {count}</h1>

    </div>
  );
}

function incrementClick() {
  dispatcher(increment());
}

function decrementClick() {
  dispatcher(decrement());
}

export default App;
