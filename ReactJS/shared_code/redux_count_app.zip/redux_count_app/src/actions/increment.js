const increment = ()=> {
    return {
      type: 'INCREMENT'
    }
}

export default increment;
