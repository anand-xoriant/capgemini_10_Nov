const decrement = ()=> {
    return {
      type: 'DECREMENT'
    }
  }
  
export default decrement;