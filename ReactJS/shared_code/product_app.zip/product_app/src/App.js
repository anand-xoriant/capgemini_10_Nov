import logo from './logo.svg';
import './App.css';
import ProductApp from './components/product_app'

function App() {
  return (
    <div className="App">
     <ProductApp></ProductApp>
    </div>
  );
}

export default App;
