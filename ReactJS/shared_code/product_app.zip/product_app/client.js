import React from 'react'
import {render} from 'react-dom'
import ProductApp from './components/product_app'

render(
<ProductApp />	
	, document.getElementById('app'))
